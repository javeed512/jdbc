package com.simplilearn.bean;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Main {

	public static void main(String[] args) {

		StandardServiceRegistry standardRegistry = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml")
				.build();

		Metadata metaData = new MetadataSources(standardRegistry).getMetadataBuilder().build();
		SessionFactory sessionFactory = metaData.getSessionFactoryBuilder().build();

		Session session = sessionFactory.openSession();

		System.out.println(session);

		session.beginTransaction();

		/*  // insert operation
		 * Employee emp = new Employee();
		 * 
		 * emp.setEid(101); // eid is auto generator emp.setEname("King");
		 * emp.setSalary(80000);
		*session.save(emp); // insert
		**/
		
		/*
		 * Employee updateEmp = new Employee(); updateEmp.setEid(1); // emp <-- select *
		 * from emp_table where eid =1; updateEmp.setEname("Mr.KING");
		 * updateEmp.setSalary(65000);// update emp_table set empname = 'Mr.KING' ,
		 * salary =65000 where eid = 1
		 * 
		 * session.update(updateEmp);
		 */
		
		
 List<Employee> list=	session.createQuery(" from Employee").list();
				
 	System.out.println(list.toString());
 	
 			
 
 			for (Employee employee : list) {
			
 				System.out.println(employee);
 				
			}
 			
 			
 			Employee emp =list.get(0);
 						
		/*
		 * Employee e1 = new Employee(); e1.setEid(111);
		 */

 						session.delete(emp);
 				
 			
 					System.out.println("Delete");
 			
 			
		
		session.getTransaction().commit();

		session.close();

	}

}
