package com.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.app.Employee;

public class EmployeeDAO {

	SessionFactory factory;

	public EmployeeDAO() {

		factory = HibernateUtililty.getSessionFactory();

	}

	public void addEmployee(Employee emp) {

		Session session = factory.openSession();

		session.getTransaction().begin();

		session.save(emp);

		session.getTransaction().commit();

	}

	public void updateEmployee(Employee emp) {

		Session session = factory.openSession();

		session.getTransaction().begin();

		session.update(emp);

		session.getTransaction().commit();

	}

	public List<Employee> getAllEmployees() {

		Session session = factory.openSession();

		session.getTransaction().begin();

		List<Employee> list = session.createQuery("from Employee").list();

		session.getTransaction().commit();

		return list;

	}
	
	
	public void deleteEmployee(Employee emp) {
		
		//delete()
		
		
	}

}
