package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.app.Employee;
import com.dao.EmployeeDAO;

/**
 * Servlet implementation class HibernateServlet
 */
@WebServlet("/HibernateServlet")
public class HibernateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public HibernateServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
			PrintWriter out =	response.getWriter();
	
				out.print("<h1>Welcome to Emloyee App</h1>");
				
				
					EmployeeDAO dao = new EmployeeDAO();
				
					String str1 =	request.getParameter("eid");
					
					String ename =	request.getParameter("ename");
					
					String str2  = request.getParameter("salary");
					
					Employee emp = new Employee();
					
						emp.setEid(Integer.parseInt(str1));
						emp.setEname(ename);
						emp.setSalary(Double.parseDouble(str2));
						
							//dao.addEmployee(emp);
				
				dao.updateEmployee(emp);
				
	
	}
	
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
			
		
	}

}
