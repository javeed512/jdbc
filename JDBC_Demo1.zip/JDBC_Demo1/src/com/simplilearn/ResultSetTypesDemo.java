package com.simplilearn;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ResultSetTypesDemo {

	public static void main(String[] args) {

		Connection conn =	DBUtil.getDBConnection();
		
		try {
			
			Statement stmt =	
			conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			
			ResultSet rs =		stmt.executeQuery("select * from employee");
				
			
			rs.absolute(2);
			
			System.out.println(rs.getInt("eid") +" "+rs.getString("ename")+ " "+rs.getDouble("salary"));
			
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}

}
