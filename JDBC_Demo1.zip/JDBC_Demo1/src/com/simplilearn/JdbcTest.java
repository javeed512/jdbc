package com.simplilearn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Connection conn = null;
		
		try {
			//step1 register driver
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			
			// step2 get DB Connection
			
			
		conn =	DriverManager.getConnection("jdbc:mysql://localhost:3306/empdb", "root", "admin");
			
		//step3
				Statement stmt =		conn.createStatement();
				
				String insert ="insert into employee values(101,'Turley',40000)";
				
				//setp4
					int count =	stmt.executeUpdate(insert);   //stmt.executeQuery(sql)
				
					if(count > 0) {
						
						System.out.println(count+" record inserted successfully");
						
					}
					else {
						
						System.out.println("Insert Failed..");
					}
					
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			
			try {
				conn.close();  //step5
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
		
	}

}
