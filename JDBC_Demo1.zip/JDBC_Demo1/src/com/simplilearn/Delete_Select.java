package com.simplilearn;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Delete_Select {

	public static void main(String[] args) {

			
		Connection conn =	DBUtil.getDBConnection();
		
		/*
		 * String deleteQuery ="delete from employee where eid = ?";
		 * 
		 * try { PreparedStatement pstmt = conn.prepareStatement(deleteQuery);
		 * 
		 * pstmt.setInt(1, 105);
		 * 
		 * boolean flag = pstmt.execute();
		 * 
		 * System.out.println("Is Record Deleted ? "+!flag);
		 * 
		 * 
		 * 
		 * 
		 * } catch (SQLException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 */
		
		
		String selectQuery ="select * from employee";
		 try {
			PreparedStatement pstmt = conn.prepareStatement(selectQuery);
			
			ResultSet rs =	pstmt.executeQuery();
			
			while(rs.next()) {
				
	System.out.println(rs.getInt("eid")+" "+rs.getString("ename")+" "+rs.getDouble("salary"));
				
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
	}

}
