package com.simplilearn;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class CallableStatementDemo {

	public static void main(String[] args) {

			
		Connection conn =	DBUtil.getDBConnection();
		
		try {
			CallableStatement cstmt =	conn.prepareCall("{call getAllEmployees()}");
		
			cstmt.execute();
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			

	}

}
