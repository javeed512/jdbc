package com.simplilearn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	
	
	public static Connection  getDBConnection() {
		
		Connection conn  = null;
		
		try {
			//step1 register driver
		//	DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			
			Class.forName("com.mysql.cj.jdbc.Driver"); // load driver
			
			// step2 get DB Connection
			
			
		conn =	DriverManager.getConnection("jdbc:mysql://localhost:3306/empdb", "root", "admin");
		}catch (SQLException e) {
		
				e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
		
	}
	
	

}
