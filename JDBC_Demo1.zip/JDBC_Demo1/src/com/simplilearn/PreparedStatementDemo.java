package com.simplilearn;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class PreparedStatementDemo {

	public static void main(String[] args) {

		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter Eid");
		
		int eid =scanner.nextInt();
		
		System.out.println("Enter EName");
		 String ename = scanner.next();
		 
		 System.out.println("Enter salary");
		 double salary = scanner.nextDouble();
		
		Connection conn =	DBUtil.getDBConnection();
		
		/*
		 * String insertQuery = "insert into employee(eid,ename,salary) values(?,?,?)";
		 * // positional parametes
		 * 
		 * try { PreparedStatement pstmt= conn.prepareStatement(insertQuery);
		 * 
		 * pstmt.setInt(1, eid); pstmt.setString(2, ename); pstmt.setDouble(3,salary);
		 * 
		 * 
		 * int count = pstmt.executeUpdate();
		 * 
		 * System.out.println(count+" record inserted..");
		 * 
		 * } catch (SQLException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 */
		
		String updateQuery = "update employee set ename = ? ,salary = ?  where eid =? ";
			try {
				PreparedStatement pstmt =	conn.prepareStatement(updateQuery);
				
					pstmt.setString(1, ename);
					pstmt.setDouble(2, salary);
					pstmt.setInt(3, eid);
				
			int count =	pstmt.executeUpdate();
			
			System.out.println(count+" record updated..");
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			
			
		
		

	}

}
